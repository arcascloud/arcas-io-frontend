import { Component, inject, signal, OnInit, DestroyRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToolbarModule } from 'primeng/toolbar';
import { SelectModule } from 'primeng/select';
import { TooltipModule } from 'primeng/tooltip';
import { MessageService, ConfirmationService } from 'primeng/api';
import { AjusteInventarioService } from '../../../core/services/ajuste-inventario.service';
import { BodegasService } from '../../../core/services/bodegas.service';
import { ProductosService } from '../../../core/services/productos.service';

@Component({
  selector: 'app-ajustes',
  standalone: true,
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule,
    TableModule, ButtonModule, InputTextModule, InputNumberModule,
    DialogModule, TagModule, ToastModule, ConfirmDialogModule,
    ToolbarModule, SelectModule, TooltipModule,
  ],
  templateUrl: './ajustes.html',
  styleUrl: './ajustes.scss',
})
export class Ajustes implements OnInit {
  private fb = inject(FormBuilder);
  private service = inject(AjusteInventarioService);
  private bodegasService = inject(BodegasService);
  private productosService = inject(ProductosService);
  private msgs = inject(MessageService);
  private confirm = inject(ConfirmationService);
  private destroyRef = inject(DestroyRef);

  maestros = signal<any[]>([]);
  detalles = signal<any[]>([]);
  bodegas = signal<any[]>([]);
  productos = signal<any[]>([]);
  seleccionado = signal<any | null>(null);
  cargando = signal(false);
  cargandoDet = signal(false);

  dialogMae = signal(false);
  dialogDet = signal(false);
  esEdicion = signal(false);

  formMae = this.fb.group({
    concepto: ['', Validators.required],
    bodegaId: [null as number | null, Validators.required],
    sn_entrada: ['S' as 'S' | 'N', Validators.required],
  });

  formDet = this.fb.group({
    producto: [null as string | null, Validators.required],
    cantidad: [0, [Validators.required, Validators.min(0.01)]],
  });

  ngOnInit() {
    this.cargarBodegas();
    this.cargarProductos();
    this.cargarMaestros();
  }

  cargarBodegas() {
    this.bodegasService.getAll().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => this.bodegas.set(data?.value || data || []),
    });
  }

  cargarProductos() {
    this.productosService.getAll().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => this.productos.set(data?.value || data || []),
    });
  }

  cargarMaestros() {
    this.cargando.set(true);
    this.service.getAll().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => {
        this.maestros.set(data?.value || data || []);
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.msgs.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron cargar los ajustes' });
      },
    });
  }

  seleccionar(row: any) {
    this.seleccionado.set(row);
    this.cargarDetalles(row.invmovmaeid);
  }

  cargarDetalles(invmovmaeid: number) {
    this.cargandoDet.set(true);
    this.service.getDet(invmovmaeid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => {
        this.detalles.set(data?.value || data || []);
        this.cargandoDet.set(false);
      },
      error: () => {
        this.cargandoDet.set(false);
        this.msgs.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron cargar los items' });
      },
    });
  }

  volver() {
    this.seleccionado.set(null);
    this.detalles.set([]);
  }

  nuevoMae() {
    this.esEdicion.set(false);
    this.formMae.reset({ concepto: '', bodegaId: null, sn_entrada: 'S' });
    this.dialogMae.set(true);
  }

  editarMae(row: any) {
    this.esEdicion.set(true);
    this.formMae.patchValue({ concepto: row.concepto, bodegaId: row.bodegaId, sn_entrada: row.sn_entrada });
    this.seleccionado.set(row);
    this.dialogMae.set(true);
  }

  guardarMae() {
    if (this.formMae.invalid) return;
    const val = this.formMae.value;
    const obs$ = this.esEdicion()
      ? this.service.update(this.seleccionado()!.invmovmaeid, val as any)
      : this.service.create(val as any);

    obs$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (res: any) => {
        this.msgs.add({ severity: 'success', summary: 'Guardado', detail: this.esEdicion() ? 'Ajuste actualizado' : 'Ajuste creado' });
        this.dialogMae.set(false);
        this.cargarMaestros();
        if (!this.esEdicion() && res.invmovmaeid) {
          this.seleccionar(res);
        }
      },
      error: () => this.msgs.add({ severity: 'error', summary: 'Error', detail: 'No se pudo guardar' }),
    });
  }

  eliminarMae(row: any) {
    this.confirm.confirm({
      message: `¿Eliminar ajuste #${row.invmovmaeid}?`,
      header: 'Confirmar',
      acceptLabel: 'Eliminar',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.service.remove(row.invmovmaeid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: () => {
            this.msgs.add({ severity: 'success', summary: 'Eliminado' });
            if (this.seleccionado()?.invmovmaeid === row.invmovmaeid) this.volver();
            this.cargarMaestros();
          },
        });
      },
    });
  }

  nuevoDet() {
    this.formDet.reset({ producto: null, cantidad: 0 });
    this.dialogDet.set(true);
  }

  guardarDet() {
    if (this.formDet.invalid) return;
    const val = this.formDet.value;
    const mae = this.seleccionado();

    const payload: any = {
      invmovmaeid: mae.invmovmaeid,
      bodegaId: mae.bodegaId,
      codbarra: val.producto,
      cantidad: val.cantidad || 0,
      sn_entrada: mae.sn_entrada,
      empresaId: mae.empresaId,
    };

    this.service.createDet(payload).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => {
        this.msgs.add({ severity: 'success', summary: 'Guardado', detail: 'Item agregado' });
        this.dialogDet.set(false);
        this.cargarDetalles(mae.invmovmaeid);
      },
      error: (err) => this.msgs.add({ severity: 'error', summary: 'Error', detail: err.error?.message || 'No se pudo guardar el item' }),
    });
  }

  eliminarDet(row: any) {
    this.confirm.confirm({
      message: `¿Eliminar item "${row.codbarra}"?`,
      header: 'Confirmar',
      accept: () => {
        this.service.removeDet(row.invmovdetid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: () => {
            this.msgs.add({ severity: 'success', summary: 'Eliminado' });
            this.cargarDetalles(this.seleccionado()!.invmovmaeid);
          },
        });
      },
    });
  }

  procesar() {
    const mae = this.seleccionado();
    if (!mae) return;
    const tipo = mae.sn_entrada === 'S' ? 'entrada' : 'salida';
    this.confirm.confirm({
      message: `¿Procesar ajuste #${mae.invmovmaeid}? Se registrará como ${tipo} en kardex.`,
      header: 'Procesar ajuste',
      acceptLabel: 'Procesar',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.confirm.close();
        this.service.procesar(mae.invmovmaeid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: (res: any) => {
            this.msgs.add({ severity: 'success', summary: 'Procesado', detail: res.message || 'Ajuste procesado' });
            this.cargarMaestros();
            this.cargarDetalles(mae.invmovmaeid);
          },
          error: (err) => this.msgs.add({ severity: 'error', summary: 'Error', detail: err.error?.message || 'No se pudo procesar' }),
        });
      },
    });
  }

  todosProcesados(): boolean {
    return this.detalles().length > 0 && this.detalles().every(d => d.verificador === 1);
  }

  nombreBodega(id: number): string {
    return this.bodegas().find(b => b.bodegaId === id)?.descripcion || `Bodega ${id}`;
  }
}
