import { Component, inject, signal, OnInit, DestroyRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { DialogModule } from 'primeng/dialog';
import { TagModule } from 'primeng/tag';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToolbarModule } from 'primeng/toolbar';
import { SelectModule } from 'primeng/select';
import { TooltipModule } from 'primeng/tooltip';
import { DatePickerModule } from 'primeng/datepicker';
import { TextareaModule } from 'primeng/textarea';
import { MessageService, ConfirmationService } from 'primeng/api';
import { RequisicionInventarioService } from '../../../core/services/requisicion-inventario.service';
import { BodegasService } from '../../../core/services/bodegas.service';
import { ProductosService } from '../../../core/services/productos.service';

@Component({
  selector: 'app-requisiciones',
  standalone: true,
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule,
    TableModule, ButtonModule, InputTextModule, InputNumberModule,
    DialogModule, TagModule, ToastModule, ConfirmDialogModule,
    ToolbarModule, SelectModule, TooltipModule, DatePickerModule, TextareaModule,
  ],
  templateUrl: './requisiciones.html',
  styleUrl: './requisiciones.scss',
})
export class Requisiciones implements OnInit {
  private fb = inject(FormBuilder);
  private service = inject(RequisicionInventarioService);
  private bodegasService = inject(BodegasService);
  private productosService = inject(ProductosService);
  private msgs = inject(MessageService);
  private confirm = inject(ConfirmationService);
  private destroyRef = inject(DestroyRef);

  maestros = signal<any[]>([]);
  detalles = signal<any[]>([]);
  bodegas = signal<any[]>([]);
  productos = signal<any[]>([]);
  seleccionado = signal<any | null>(null);
  cargando = signal(false);
  cargandoDet = signal(false);

  dialogMae = signal(false);
  dialogDet = signal(false);
  esEdicion = signal(false);

  prioridades = signal<{ label: string; value: string }[]>([
    { label: 'Baja', value: 'B' },
    { label: 'Media', value: 'M' },
    { label: 'Alta', value: 'A' },
    { label: 'Urgente', value: 'U' },
  ]);

  formMae = this.fb.group({
    concepto: ['', Validators.required],
    bodegaOrigenId: [null as number | null, Validators.required],
    bodegaDestinoId: [null as number | null, Validators.required],
    prioridad: ['M', Validators.required],
    fechaEntrega: [null as Date | null],
    observaciones: [''],
  });

  formDet = this.fb.group({
    producto: [null as string | null, Validators.required],
    cantidadSolicitada: [0, [Validators.required, Validators.min(0.01)]],
  });

  ngOnInit() {
    this.cargarBodegas();
    this.cargarProductos();
    this.cargarMaestros();
  }

  cargarBodegas() {
    this.bodegasService.getAll().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => this.bodegas.set(data?.value || data || []),
    });
  }

  cargarProductos() {
    this.productosService.getAll().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => this.productos.set(data?.value || data || []),
    });
  }

  cargarMaestros() {
    this.cargando.set(true);
    this.service.getAll().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => {
        this.maestros.set(data?.value || data || []);
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.msgs.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron cargar las requisiciones' });
      },
    });
  }

  seleccionar(row: any) {
    this.seleccionado.set(row);
    this.cargarDetalles(row.invreqmaeid);
  }

  cargarDetalles(invreqmaeid: number) {
    this.cargandoDet.set(true);
    this.service.getDet(invreqmaeid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (data: any) => {
        this.detalles.set(data?.value || data || []);
        this.cargandoDet.set(false);
      },
      error: () => {
        this.cargandoDet.set(false);
        this.msgs.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron cargar los items' });
      },
    });
  }

  volver() {
    this.seleccionado.set(null);
    this.detalles.set([]);
  }

  nuevoMae() {
    this.esEdicion.set(false);
    this.formMae.reset({ concepto: '', bodegaOrigenId: null, bodegaDestinoId: null, prioridad: 'M', fechaEntrega: null, observaciones: '' });
    this.dialogMae.set(true);
  }

  editarMae(row: any) {
    if (row.sn_estado !== 'P') {
      this.msgs.add({ severity: 'warn', summary: 'Solo pendientes', detail: 'Solo se pueden editar requisiciones pendientes' });
      return;
    }
    this.esEdicion.set(true);
    this.formMae.patchValue({
      concepto: row.concepto,
      bodegaOrigenId: row.bodegaOrigenId,
      bodegaDestinoId: row.bodegaDestinoId,
      prioridad: row.prioridad || 'M',
      fechaEntrega: row.fechaEntrega ? new Date(row.fechaEntrega) : null,
      observaciones: row.observaciones || '',
    });
    this.seleccionado.set(row);
    this.dialogMae.set(true);
  }

  guardarMae() {
    if (this.formMae.invalid) return;
    const val = this.formMae.value;

    if (val.bodegaOrigenId === val.bodegaDestinoId) {
      this.msgs.add({ severity: 'warn', summary: 'Bodegas', detail: 'La bodega origen y destino deben ser diferentes' });
      return;
    }

    const obs$ = this.esEdicion()
      ? this.service.update(this.seleccionado()!.invreqmaeid, val as any)
      : this.service.create(val as any);

    obs$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (res: any) => {
        this.msgs.add({ severity: 'success', summary: 'Guardado', detail: this.esEdicion() ? 'Requisición actualizada' : 'Requisición creada' });
        this.dialogMae.set(false);
        this.cargarMaestros();
        if (!this.esEdicion() && res.invreqmaeid) {
          this.seleccionar(res);
        }
      },
      error: (err) => this.msgs.add({ severity: 'error', summary: 'Error', detail: err.error?.message || 'No se pudo guardar' }),
    });
  }

  eliminarMae(row: any) {
    if (row.sn_estado !== 'P') {
      this.msgs.add({ severity: 'warn', summary: 'Solo pendientes', detail: 'Solo se pueden eliminar requisiciones pendientes' });
      return;
    }
    this.confirm.confirm({
      message: `¿Eliminar requisición #${row.invreqmaeid}?`,
      header: 'Confirmar',
      acceptLabel: 'Eliminar',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.service.remove(row.invreqmaeid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: () => {
            this.msgs.add({ severity: 'success', summary: 'Eliminada' });
            if (this.seleccionado()?.invreqmaeid === row.invreqmaeid) this.volver();
            this.cargarMaestros();
          },
        });
      },
    });
  }

  nuevoDet() {
    this.formDet.reset({ producto: null, cantidadSolicitada: 0 });
    this.dialogDet.set(true);
  }

  guardarDet() {
    if (this.formDet.invalid) return;
    const val = this.formDet.value;
    const mae = this.seleccionado();

    const payload: any = {
      invreqmaeid: mae.invreqmaeid,
      codbarra: val.producto,
      cantidadSolicitada: val.cantidadSolicitada || 0,
      empresaId: mae.empresaId,
    };

    this.service.createDet(payload).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: () => {
        this.msgs.add({ severity: 'success', summary: 'Guardado', detail: 'Item agregado' });
        this.dialogDet.set(false);
        this.cargarDetalles(mae.invreqmaeid);
      },
      error: (err) => this.msgs.add({ severity: 'error', summary: 'Error', detail: err.error?.message || 'No se pudo guardar el item' }),
    });
  }

  eliminarDet(row: any) {
    this.confirm.confirm({
      message: `¿Eliminar item "${row.codbarra}"?`,
      header: 'Confirmar',
      accept: () => {
        this.service.removeDet(row.invreqdetid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: () => {
            this.msgs.add({ severity: 'success', summary: 'Eliminado' });
            this.cargarDetalles(this.seleccionado()!.invreqmaeid);
          },
        });
      },
    });
  }

  procesar() {
    const mae = this.seleccionado();
    if (!mae) return;
    this.confirm.confirm({
      message: `¿Aprobar requisición #${mae.invreqmaeid}?`,
      header: 'Aprobar requisición',
      acceptLabel: 'Aprobar',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.service.procesar(mae.invreqmaeid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: (res: any) => {
            this.msgs.add({ severity: 'success', summary: 'Aprobada', detail: res.message || 'Requisición aprobada' });
            this.cargarMaestros();
            this.cargarDetalles(mae.invreqmaeid);
          },
          error: (err) => this.msgs.add({ severity: 'error', summary: 'Error', detail: err.error?.message || 'No se pudo procesar' }),
        });
      },
    });
  }

  anular() {
    const mae = this.seleccionado();
    if (!mae) return;
    this.confirm.confirm({
      message: `¿Anular requisición #${mae.invreqmaeid}?`,
      header: 'Anular requisición',
      acceptLabel: 'Anular',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.service.anular(mae.invreqmaeid).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: (res: any) => {
            this.msgs.add({ severity: 'success', summary: 'Anulada', detail: res.message || 'Requisición anulada' });
            this.cargarMaestros();
            this.cargarDetalles(mae.invreqmaeid);
          },
          error: (err) => this.msgs.add({ severity: 'error', summary: 'Error', detail: err.error?.message || 'No se pudo anular' }),
        });
      },
    });
  }

  nombreBodega(id: number): string {
    return this.bodegas().find(b => b.bodegaId === id)?.descripcion || `Bodega ${id}`;
  }

  estadoLabel(estado: string): string {
    const map: Record<string, string> = { P: 'Pendiente', A: 'Aprobada', R: 'Recibida', X: 'Anulada' };
    return map[estado] || estado;
  }

  estadoSeverity(estado: string): string {
    const map: Record<string, string> = { P: 'warn', A: 'success', R: 'info', X: 'danger' };
    return map[estado] || 'secondary';
  }

  esPendiente(): boolean {
    return this.seleccionado()?.sn_estado === 'P';
  }

  prioridadLabel(p: string): string {
    const map: Record<string, string> = { B: 'Baja', M: 'Media', A: 'Alta', U: 'Urgente' };
    return map[p] || p;
  }

  prioridadSeverity(p: string): string {
    const map: Record<string, string> = { B: 'info', M: 'warn', A: 'danger', U: 'danger' };
    return map[p] || 'secondary';
  }
}
