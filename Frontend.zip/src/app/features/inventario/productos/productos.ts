import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DataViewModule } from 'primeng/dataview';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { SelectButtonModule } from 'primeng/selectbutton';
import { MessageService } from 'primeng/api';
import { ApiService } from '../../../core/services/api.service';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    DataViewModule,
    ButtonModule,
    InputTextModule,
    TagModule,
    TooltipModule,
    SelectButtonModule,
  ],
  templateUrl: './productos.html',
  styleUrl: './productos.scss',
})
export class Productos implements OnInit {
  private api = inject(ApiService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private msgs = inject(MessageService);

  private imagenCache = new Map<string, string>();

  data = signal<any[]>([]);
  filtered = signal<any[]>([]);
  cargando = signal(false);

  q = signal('');
  layout: 'list' | 'grid' = 'list';
  options: any[] = [{ icon: 'pi pi-bars', value: 'list' }, { icon: 'pi pi-th-large', value: 'grid' }];

  ngOnInit() {
    this.load();
  }

  load() {
    this.cargando.set(true);
    forkJoin([
      this.api.get<any[]>('/inventario/productos'),
      this.api.get<any[]>('/inventario/productos-img')
    ]).subscribe({
      next: ([productos, imagenes]) => {
        const imgMap = new Map<number, string>();
        for (const img of imagenes) {
          if (img.img) imgMap.set(img.productoId, img.img);
        }
        this.data.set(productos.map(p => ({
          ...p,
          imagen: imgMap.get(p.produtoId) || ''
        })));
        this.filtrar();
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.msgs.add({
          severity: 'error',
          summary: 'Error',
          detail: 'No se pudieron cargar los productos',
        });
      },
    });
  }

  filtrar() {
    const q = this.q().toLowerCase();
    this.filtered.set(
      this.data().filter((p) => {
        if (!q) return true;
        return (
          p.descripcion?.toLowerCase().includes(q) ||
          p.descripcion_corta?.toLowerCase().includes(q) ||
          p.codbarra?.toLowerCase().includes(q)
        );
      }),
    );
  }

  buscar() {
    this.filtrar();
  }

  limpiarFiltros() {
    this.q.set('');
    this.filtrar();
  }

  nuevo() {
    this.router.navigate(['nuevo'], { relativeTo: this.route });
  }

  editar(id?: number, e?: Event) {
    e?.stopPropagation();
    if (!id) return;
    this.router.navigate(['editar', id], { relativeTo: this.route });
  }

  resolverImagen(imagen: string | null): string {
    if (!imagen) return '';
    const cacheKey = imagen.substring(0, 100);
    if (this.imagenCache.has(cacheKey)) return this.imagenCache.get(cacheKey)!;
    const result = /^data:/i.test(imagen) ? imagen : `data:image/png;base64,${imagen}`;
    this.imagenCache.set(cacheKey, result);
    return result;
  }

  getItemImagen(item: any): string {
    if (item.imagen) return this.resolverImagen(item.imagen);
    return '';
  }

  activoLbl(sn: string): string {
    return sn === 'S' ? 'Activo' : 'Inactivo';
  }

  activoSev(sn: string): 'success' | 'danger' {
    return sn === 'S' ? 'success' : 'danger';
  }

  moneda(n: number | undefined): string {
    return (n ?? 0).toLocaleString('es-HN', {
      style: 'currency',
      currency: 'HNL',
    });
  }
}