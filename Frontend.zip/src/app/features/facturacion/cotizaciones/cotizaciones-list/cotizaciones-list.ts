﻿import { Component, inject, signal, OnInit, DestroyRef } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { DataViewModule } from 'primeng/dataview';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TagModule } from 'primeng/tag';
import { TooltipModule } from 'primeng/tooltip';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ApiService } from '../../../../core/services/api.service';

@Component({
  selector: 'app-cotizaciones-list',
  standalone: true,
  imports: [CommonModule, FormsModule, DataViewModule, ButtonModule, InputTextModule, TagModule, TooltipModule, ConfirmDialogModule],
  providers: [ConfirmationService],
  templateUrl: './cotizaciones-list.html',
  styleUrl: './cotizaciones-list.scss',
})
export class CotizacionesList implements OnInit {
  private api = inject(ApiService);
  private router = inject(Router);
  private msgs = inject(MessageService);
  private confirmation = inject(ConfirmationService);
  private destroyRef = inject(DestroyRef);

  data = signal<any[]>([]);
  filtered = signal<any[]>([]);
  cargando = signal(false);
  q = signal('');
  layout: 'list' | 'grid' = 'list';

  ngOnInit() {
    this.load();
  }

  load() {
    this.cargando.set(true);
    this.api.get<any>('/facturacion/cotizaciones').pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
      next: (res) => {
        const items = res?.value ?? (Array.isArray(res) ? res : []);
        this.data.set(items);
        this.filtrar();
        this.cargando.set(false);
      },
      error: () => {
        this.cargando.set(false);
        this.msgs.add({ severity: 'error', summary: 'Error', detail: 'No se pudieron cargar las cotizaciones' });
      },
    });
  }

  filtrar() {
    const q = this.q().toLowerCase();
    this.filtered.set(
      this.data().filter((i) => {
        if (!q) return true;
        return JSON.stringify(i).toLowerCase().includes(q);
      }),
    );
  }

  buscar() {
    this.filtrar();
  }

  limpiarFiltros() {
    this.q.set('');
    this.filtrar();
  }

  nuevo() {
    this.router.navigate(['/facturacion/cotizaciones/editar', 'nuevo']);
  }

  editar(id: number) {
    this.router.navigate(['/facturacion/cotizaciones/editar', id]);
  }

  eliminar(item: any, event: Event) {
    this.confirmation.confirm({
      target: event.target as EventTarget,
      message: `¿Eliminar cotización #${item.poscotmaeId}?`,
      header: 'Confirmar eliminación',
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: 'Eliminar',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.api.delete<any>('/facturacion/cotizaciones', item.poscotmaeId).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
          next: () => {
            this.msgs.add({ severity: 'success', summary: 'Eliminada', detail: 'Cotización eliminada' });
            this.load();
          },
          error: () => {
            this.msgs.add({ severity: 'error', summary: 'Error', detail: 'No se pudo eliminar la cotización' });
          },
        });
      },
    });
  }

  estadoLabel(item: any): string {
    switch (item.sn_estadocarrito) {
      case 'A': return 'Activa';
      case 'F': return 'Facturada';
      case 'X': return 'Anulada';
      default: return item.sn_estadocarrito ?? 'N/A';
    }
  }

  estadoSeverity(item: any): string {
    switch (item.sn_estadocarrito) {
      case 'A': return 'success';
      case 'F': return 'info';
      case 'X': return 'danger';
      default: return 'secondary';
    }
  }

  moneda(n: number | undefined): string {
    return (n ?? 0).toLocaleString('es-HN', { style: 'currency', currency: 'HNL' });
  }
}
