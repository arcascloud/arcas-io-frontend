##License
**© Copyright 2018 - 2020 Visa. All Rights Reserved.**

*NOTICE: The software and accompanying information and documentation (together, the “Software”) remain the property of and are proprietary to Visa and its suppliers and affiliates. The Software remains protected by intellectual property rights and may be covered by U.S. and foreign patents or patent applications. The Software is licensed and not sold.*

*By accessing the Software you are agreeing to Visa's terms of use (developer.visa.com/terms) and privacy policy (developer.visa.com/privacy).In addition, all permissible uses of the Software must be in support of Visa products, programs and services provided through the Visa Developer Program (VDP) platform only (developer.visa.com). **THE SOFTWARE AND ANY ASSOCIATED INFORMATION OR DOCUMENTATION IS PROVIDED ON AN “AS IS,” “AS AVAILABLE,” “WITH ALL FAULTS” BASIS WITHOUT WARRANTY OR CONDITION OF ANY KIND. YOUR USE IS AT YOUR OWN RISK.** All brand names are the property of their respective owners, used for identification purposes only, and do not imply product endorsement or affiliation with Visa. Any links to third party sites are for your information only and equally do not constitute a Visa endorsement. Visa has no insight into and control over third party content and code and disclaims all liability for any such components, including continued availability and functionality. Benefits depend on implementation details and business factors and coding steps shown are exemplary only and do not reflect all necessary elements for the described capabilities. Capabilities and features are subject to Visa’s terms and conditions and may require development,implementation and resources by you based on your business and operational details. Please refer to the specific API documentation for details on the requirements, eligibility and geographic availability.*

*This Software includes programs, concepts and details under continuing development by Visa. Any Visa features,functionality, implementation, branding, and schedules may be amended, updated or canceled at Visa’s discretion.The timing of widespread availability of programs and functionality is also subject to a number of factors outside Visa’s control,including but not limited to deployment of necessary infrastructure by issuers, acquirers, merchants and mobile device manufacturers.*

***This sample code is licensed only for use in a non-production environment for sandbox testing. See the license for all terms of use.***
### Prerequisites

VISA uses a number of open source projects to work properly:

* Java >=1.6
* Nimbus JOSE + JWT
* Bouncy Castle
* Maven

### Installation

Install the dependencies and dev Dependencies and start the sample code.

```sh
$ cd <project_directory>/jwe-jws-encryption-utils
$ mvn clean install
```

### Usage

You can the library as dependency into your maven project as follows:

```sh
  <dependencies>
        .....
        <dependency>
          <groupId>com.visa.ddp.cise.utils</groupId>
          <artifactId>jwe-jws-encryption-utils</artifactId>
          <version>1.0.1</version>
        </dependency>
        .....
  </dependencies>
```

Please check the unit test for usage and may need to be adjusted as per VISA specifications for the product/apis you are integrating.

```sh
     //If you have a private key file, please use below code to load the private key. Private key should be in PEM format
     RSAPrivateKey privateKey = CertificateUtils.loadPrivateKeyFromFile("<PRIVATE_KEY_FILE_PATH>");

     //If you have a public key or certificate file, please use below code to load the private key. Public key or certificate should be in PEM format
     RSAPublicKey publicKey = CertificateUtils.loadPublicKeyFromFile("<PUBLIC KEY FILE OR CERTIFICATE FILE PATH>");
```

### Changelog
 - Version 1.0.0
    - Sample code for Symmetric & Asymmetric Encryption/Decryption using JWE & JWS
    - Add Sample code to load public and private key from file.
 - Version 1.0.1
   - Add Sample codes for loading public and private key from PEM file